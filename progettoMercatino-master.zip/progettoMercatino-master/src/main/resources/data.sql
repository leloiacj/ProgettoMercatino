

INSERT INTO categoria(nome, foto) VALUES('abbigliamento e accessori', 'https://www.mercatinousato.com/prodotti/abbigliamento-e-accessori/1c');
INSERT INTO categoria(nome, foto) VALUES('casa e cucina', 'https://www.mercatinousato.com/prodotti/casa-e-cucina/2c');
INSERT INTO categoria(nome, foto) VALUES('elettronica', 'https://www.mercatinousato.com/prodotti/elettronica/9c');
INSERT INTO categoria(nome, foto) VALUES('libri', 'https://www.mercatinousato.com/prodotti/libri-musica-e-film/3c');
INSERT INTO categoria(nome, foto) VALUES('musica e film', 'https://www.mercatinousato.com/prodotti/libri-musica-e-film/3c');
INSERT INTO categoria(nome, foto) VALUES('sport e hobby', 'https://www.mercatinousato.com/prodotti/sport-e-hobby/8c');


INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Abito sera', 						'50', 		'"C:\Users\andre\Downloads\JUST BURGER.png"', '1');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Set piatti', 						'15', 		'"C:\Users\andre\Downloads\JUST BURGER.png"', '2');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Computer', 							'2500', 	'"C:\Users\andre\Downloads\JUST BURGER.png"', '3');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Il signore degli anelli, trilogia', 	'10', 		'"C:\Users\andre\Downloads\JUST BURGER.png"', '4');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Greatest hits Dire Straits', 		'9.99', 	'"C:\Users\andre\Downloads\JUST BURGER.png"', '5');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Mountain Bike', 						'150', 		'"C:\Users\andre\Downloads\JUST BURGER.png"', '6');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Scarpe', 							'70', 		'"C:\Users\andre\Downloads\JUST BURGER.png"', '1');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Moka 6 persone', 					'30', 		'"C:\Users\andre\Downloads\JUST BURGER.png"', '2');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Televisore HD', 						'1500', 	'"C:\Users\andre\Downloads\JUST BURGER.png"', '3');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Matematica for dummies', 			'6.90', 	'"C:\Users\andre\Downloads\JUST BURGER.png"', '4');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Shrek', 								'12.90', 	'"C:\Users\andre\Downloads\JUST BURGER.png"', '5');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Racchetta da tennis professionale', 	'100', 		'"C:\Users\andre\Downloads\JUST BURGER.png"', '6');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Borsa pitone', 						'75', 		'"C:\Users\andre\Downloads\JUST BURGER.png"', '1');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Piatto portata con disegno',			'15', 		'"C:\Users\andre\Downloads\JUST BURGER.png"', '2');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('GTA V GOTY Edition', 				'45', 		'"C:\Users\andre\Downloads\JUST BURGER.png"', '3');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Libro, di Maccio Capatonda', 		'5.50', 	'"C:\Users\andre\Downloads\JUST BURGER.png"', '4');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Scrubs cofanetto stagione1', 		'29.99', 	'"C:\Users\andre\Downloads\JUST BURGER.png"', '5');
INSERT INTO articolo(nome, prezzo, foto, categoria_id) VALUES('Palla da calcio Mondiali 2006', 		'3.99', 	'"C:\Users\andre\Downloads\JUST BURGER.png"', '6');
