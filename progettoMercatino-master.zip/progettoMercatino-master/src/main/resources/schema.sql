CREATE SCHEMA project_work;

USE project_work;

CREATE TABLE categoria(
	id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(255) UNIQUE NOT NULL,
    foto VARCHAR(1024) 
);

CREATE TABLE articolo(
	id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(255) NOT NULL,
    descrizione VARCHAR(1024),
    prezzo DOUBLE NOT NULL CHECK (prezzo > 0),
    foto VARCHAR(1024), 
    categoria_id INT NOT NULL REFERENCES categoria(id)
);