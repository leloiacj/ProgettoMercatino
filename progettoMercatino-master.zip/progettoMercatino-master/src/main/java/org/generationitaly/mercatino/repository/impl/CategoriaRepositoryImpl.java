package org.generationitaly.mercatino.repository.impl;

import org.generationitaly.mercatino.entity.Categoria;
import org.generationitaly.mercatino.repository.CategoriaRepository;

public class CategoriaRepositoryImpl extends JpaRepositoryImpl<Categoria, Integer> implements CategoriaRepository {

}
