package org.generationitaly.mercatino.repository;

import org.generationitaly.mercatino.entity.Articolo;

public interface ArticoloRepository extends JpaRepository<Articolo, Integer> {

}
