package org.generationitaly.mercatino.repository;

import java.util.List;

import org.generationitaly.mercatino.entity.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Integer>{
	
	
}
