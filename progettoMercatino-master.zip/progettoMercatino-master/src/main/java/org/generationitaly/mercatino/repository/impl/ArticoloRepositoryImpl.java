package org.generationitaly.mercatino.repository.impl;

import org.generationitaly.mercatino.entity.Articolo;
import org.generationitaly.mercatino.repository.ArticoloRepository;

public class ArticoloRepositoryImpl extends JpaRepositoryImpl<Articolo, Integer> implements ArticoloRepository{

}
